import list from './list.json'

export class DataStore {
  static list = list
}