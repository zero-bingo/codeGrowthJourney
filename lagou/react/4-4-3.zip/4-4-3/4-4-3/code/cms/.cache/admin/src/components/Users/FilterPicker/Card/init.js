const init = initialState => {
  return initialState;
};

export default init;
