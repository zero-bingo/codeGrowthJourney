import styled from 'styled-components';

const LeftMenuListLink = styled.div`
  max-height: 180px;
  margin-bottom: 19px;
  margin-right: 28px;
  overflow: auto;
`;

export default LeftMenuListLink;
