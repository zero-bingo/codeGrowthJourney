import styled from 'styled-components';

const BaselineAlignment = styled.div`
  padding-top: 1px;
`;

export default BaselineAlignment;
