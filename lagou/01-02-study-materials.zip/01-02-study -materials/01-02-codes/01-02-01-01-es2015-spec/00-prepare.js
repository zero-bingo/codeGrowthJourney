console.log('准备工作')
