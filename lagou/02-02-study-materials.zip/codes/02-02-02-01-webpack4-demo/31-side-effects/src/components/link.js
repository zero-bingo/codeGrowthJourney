export default () => {
  return document.createElement('a')
}
