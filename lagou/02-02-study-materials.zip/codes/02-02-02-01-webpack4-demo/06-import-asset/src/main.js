import createHeading from './heading.js'
import './main.css'

const heading = createHeading()

document.body.append(heading)
