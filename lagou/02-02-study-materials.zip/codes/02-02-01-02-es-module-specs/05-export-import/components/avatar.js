export var Avatar = 'Avatar Component'
