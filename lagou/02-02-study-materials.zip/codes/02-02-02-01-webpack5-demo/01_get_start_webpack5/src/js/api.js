const getInfo = () => {
  return {
    name: 'zce',
    age: 40
  }
}

module.exports = getInfo