import './js/Image'

/**
 * asset module type
 * 01 asset/resource -->file-loader( 输出路径 )
 * 02 asset/inline --->url-loader（所有 data uri）
 * 03 asset/source --->raw-loader
 * 04 asset （parser ）
 */
