console.log('拉勾教育前端')

// foo 函数，可是在后续代码当中并没有使用 foo 函数
// 
function foo() {
  console.log('测试函数')
}
