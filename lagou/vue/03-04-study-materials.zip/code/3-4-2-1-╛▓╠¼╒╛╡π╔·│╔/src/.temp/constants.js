export const NOT_FOUND_NAME = "404"
export const NOT_FOUND_PATH = "/404"
