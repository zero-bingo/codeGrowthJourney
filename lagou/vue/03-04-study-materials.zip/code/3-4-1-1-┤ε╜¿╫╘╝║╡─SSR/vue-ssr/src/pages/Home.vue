<template>
  <div>
    <h1>Home Page</h1>
  </div>
</template>

<script>
export default {
  name: 'HomePage',
  metaInfo: {
    title: '首页'
  }
}
</script>

<style>

</style>
