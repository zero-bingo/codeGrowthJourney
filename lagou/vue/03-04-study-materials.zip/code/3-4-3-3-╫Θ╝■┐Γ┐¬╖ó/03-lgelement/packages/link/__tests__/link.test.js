import { mount } from '@vue/test-utils'
import Element from '../src/link.vue'

describe('Lg-Link', () => {
})
