import LgSteps from './src/steps.vue'

LgSteps.install = Vue => {
  Vue.component(LgSteps.name, LgSteps)
}

export default LgSteps
